long fn_call_svc(char *c_ServiceName,
				 char *c_err_msg,
				 void *st_input,
				 void *st_output,
				 char *c_inp_view,
				 char *c_out_view,
				 /int  i_ip_len,/ /* Ver 1.3 */
				 long l_ip_len,
				 /int  i_op_len, */ / Ver 1.3 */
				 long l_op_len,
				 long int li_flg,
				 char c_svcnm) / Ver 1.3 64 bit portability : return type int changed to long */
{
	/int  i_returncode;/
	long l_returncode; /* Ver 1.3 64 bit portability */
	long li_recvbuf;
	struct vw_err_msg st_err;
	void *ptr_view_Ibuf;
	void *ptr_view_Obuf;

	ptr_view_Ibuf = (char *)tpalloc("VIEW32",
									c_inp_view,
									l_ip_len); /* ver 1.3 i_ip_len changed to l_ip_len  */
	if (ptr_view_Ibuf == NULL)
	{
		fn_errlog(c_ServiceName, "L31005", TPMSG, c_err_msg);
		return (SYSTEM_ERROR);
	}

	ptr_view_Obuf = (char *)tpalloc("VIEW32",
									c_out_view,
									l_op_len); /* ver 1.3 i_op_len changed to l_op_len  */
	if (ptr_view_Obuf == NULL)
	{
		fn_errlog(c_ServiceName, "L31010", TPMSG, c_err_msg);
		tpfree((char *)ptr_view_Ibuf);
		return (SYSTEM_ERROR);
	}

	memcpy((char *)ptr_view_Ibuf,
		   (char *)st_input,
		   l_ip_len); /* ver 1.3 */

	l_returncode = tpcall(c_svcnm,
						  (char *)ptr_view_Ibuf,
						  0,
						  (char **)&ptr_view_Obuf,
						  &li_recvbuf,
						  li_flg);
	if (l_returncode == -1)
	{
		if (TPCODE == TPESVCFAIL)
		{
			l_returncode = tpurcode;
			if (tpurcode == NO_BFR)
			{
				strcpy(c_err_msg, "Resource not available");
			}
			else if (tpurcode == ERR_BFR)
			{
				memcpy((char *)&st_err,
					   (char *)ptr_view_Obuf,
					   sizeof(st_err));
				strcpy(c_err_msg, st_err.c_err_msg);
			}
			/* 1.1  - code added - start */
			else if (tpurcode == INSUFFICIENT_LIMITS)
			{
				memcpy((char *)&st_err,
					   (char *)ptr_view_Obuf,
					   sizeof(st_err));
				strcpy(c_err_msg, st_err.c_err_msg);
			}
			/* 1.1 - end */
			else
			{
				memcpy((char *)st_output,
					   (char *)ptr_view_Obuf,
					   l_op_len); /* Ver 1.3 */
			}
		}
		else
		{
			fn_errlog(c_ServiceName, "L31015", TPMSG, c_err_msg);
			/*	i_returncode = SYSTEM_ERROR;	*/
			l_returncode = SYSTEM_ERROR; /* Ver 1.3 64 bit portability */
		}
		tpfree((char *)ptr_view_Ibuf);
		tpfree((char *)ptr_view_Obuf);
		/return ( i_returncode );/
		return (l_returncode); /* Ver 1.3 64 bit portability */
	}

	/*	i_returncode = tpurcode;	*/
	l_returncode = tpurcode; /* Ver 1.3 64 bit portability */
	memcpy((char *)st_output,
		   (char *)ptr_view_Obuf,
		   l_op_len); /* Ver 1.3 */

	tpfree((char *)ptr_view_Ibuf);
	tpfree((char *)ptr_view_Obuf);

	/return ( i_returncode );/
	return (l_returncode); /* Ver 1.3 64 bit portability */
}