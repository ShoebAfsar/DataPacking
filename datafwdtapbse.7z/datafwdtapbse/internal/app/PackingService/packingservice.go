package packingservice

import (
	"bytes"
	"datafwdtapbse/internal/models"
	"datafwdtapbse/util"
	"datafwdtapbse/util/OrderConversion"
	"datafwdtapbse/util/TypeConversion"
	"encoding/binary"
	"fmt"
	"log"
	"math"
	"strconv"
	"unsafe"

	"gorm.io/gorm"
)

var l_vendor_cd int64 = 0
var lPrgrmTrdngFlg int64
var l_mdfctn_cnt int64 = 0
var c_lmt_mrkt_sl_flg string
var l_previous_qty int64 = 0
var l_exctd_qty int64 = 0
var l_modified_qty int64 = 0
var l_stp_loss_trgr int64 = 0

// var v_ack_number string
var c_location_id string
var sqlIcdCustType string = ""

type ExchngPackLibMaster struct {
	ServiceName  string
	xchngbook    *models.Vw_xchngbook
	orderbook    *models.Vw_orderbook
	pipe_mstr    *models.St_opm_pipe_mstr
	nse_contract *models.Vw_nse_cntrct
	// oe_reqres    *models.St_oe_reqres
	// exch_msg     *models.St_exch_msg
	// net_hdr      *models.St_net_hdr
	// q_packet     *models.St_req_q_data
	// int_header   *models.St_int_header
	// contract_desc   *models.St_contract_desc
	// order_flag      *models.St_order_flags
	st_ord_snd_rqst *models.StOrdRqst
	st_req_q_data   *models.St_req_q_data
	sthdr           *models.St_bfo_header
	OCM             *OrderConversion.OrderConversionManager
	// cPanNo          [util.LEN_PAN]byte
	// cLstActRef      [22]byte
	// cEspID          [51]byte
	// cAlgoID         [51]byte
	// cSourceFlg      byte
	// cPrgmFlg        byte
	// cUserTypGlb     byte
	LoggerManager *util.LoggerManager
	TCUM          *TypeConversion.TypeConversionUtilManager
	Mtype         *int
	Db            *gorm.DB
}

func NewExchngPackLibMaster(serviceName string,
	xchngbook *models.Vw_xchngbook,
	orderbook *models.Vw_orderbook,
	pipe_mstr *models.St_opm_pipe_mstr,
	nseContract *models.Vw_nse_cntrct,
	st_ord_snd_rqst *models.StOrdRqst,
	sthdr *models.St_bfo_header,
	OCM *OrderConversion.OrderConversionManager,
	Log *util.LoggerManager,
	TCUM *TypeConversion.TypeConversionUtilManager,
	mtype *int,
	Db *gorm.DB) *ExchngPackLibMaster {

	return &ExchngPackLibMaster{
		ServiceName:     serviceName,
		xchngbook:       xchngbook,
		orderbook:       orderbook,
		pipe_mstr:       pipe_mstr,
		nse_contract:    nseContract,
		st_ord_snd_rqst: st_ord_snd_rqst,
		OCM:             OCM,
		LoggerManager:   Log,
		TCUM:            TCUM,
		sthdr:           sthdr,
		Mtype:           mtype,
		Db:              Db,
	}
}

func (eplm *ExchngPackLibMaster) FnPAckOrdnryOrdToBse() int {

	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] Inside 'FnPAckOrdnryOrdToBse' ")

	if eplm.orderbook != nil {
		fmt.Println("||||||||||||||||||||||||||||||")
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book data...")
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_pro_cli_ind received: '%s'", eplm.orderbook.C_pro_cli_ind)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_cln_mtch_accnt received: '%s'", eplm.orderbook.C_cln_mtch_accnt)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_ordr_flw received: '%s'", eplm.orderbook.C_ordr_flw)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book l_ord_tot_qty received: '%d'", eplm.orderbook.L_ord_tot_qty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book l_exctd_qty received: '%d'", eplm.orderbook.L_exctd_qty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book l_exctd_qty_day received: '%d'", eplm.orderbook.L_exctd_qty_day)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_settlor received: '%s'", eplm.orderbook.C_settlor)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_ctcl_id received: '%s'", eplm.orderbook.C_ctcl_id)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_ack_tm received: '%s'", eplm.orderbook.C_ack_tm)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Order book c_prev_ack_tm received: '%s'", eplm.orderbook.C_prev_ack_tm)
	} else {
		eplm.LoggerManager.LogError(eplm.ServiceName, " [fnPackOrdnryOrdToNse] No data received in orderbook in 'fnPackOrdnryOrdToNse'")
		eplm.LoggerManager.LogError(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exiting from 'fnPackOrdnryOrdToNse'")
		return -1
	}

	if eplm.xchngbook != nil {
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book data...")
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book c_req_typ received: '%s'", eplm.xchngbook.C_req_typ)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book l_dsclsd_qty received: '%d'", eplm.xchngbook.L_dsclsd_qty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book c_slm_flg received: '%s'", eplm.xchngbook.C_slm_flg)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book l_ord_lmt_rt received: '%d'", eplm.xchngbook.L_ord_lmt_rt)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book l_stp_lss_tgr received: '%d'", eplm.xchngbook.L_stp_lss_tgr)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book c_ord_typ received: '%s'", eplm.xchngbook.C_ord_typ)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book l_ord_tot_qty received: '%d'", eplm.xchngbook.L_ord_tot_qty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book c_valid_dt received: '%s'", eplm.xchngbook.C_valid_dt)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exchange book l_ord_seq received: '%d'", eplm.xchngbook.L_ord_seq)

	} else {
		eplm.LoggerManager.LogError(eplm.ServiceName, " [fnPackOrdnryOrdToNse] No data received in xchngbook in 'fnPackOrdnryOrdToNse'")
		eplm.LoggerManager.LogError(eplm.ServiceName, " [fnPackOrdnryOrdToNse] Exiting from 'fnPackOrdnryOrdToNse'")
		return -1
	}

	l_vendor_cd = util.VENDOR_CODE

	eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] [li_opm_user_id :%ld:", eplm.pipe_mstr.Li_opm_user_id)
	eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] [c_xchng_brkr_id :%s:", eplm.pipe_mstr.C_xchng_brkr_id)
	fmt.Println("{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}")
	if eplm.orderbook.C_ctcl_id == "5555555555555" {
		lPrgrmTrdngFlg = util.PRGRM_MOBL_TRNDNG_FLG
	} else {
		lPrgrmTrdngFlg = util.PRGRM_TRNDNG_FLG
	}
	c_location_id = fmt.Sprintf("%s%d%d", eplm.orderbook.C_ctcl_id, lPrgrmTrdngFlg, l_vendor_cd)

	eplm.LoggerManager.LogInfo(eplm.ServiceName, "Location ID :%s:", c_location_id)

	if eplm.orderbook.C_slm_flg == string(util.LIMIT_ORDR_RQST) ||
		eplm.orderbook.C_slm_flg == string(util.MARKET_ORDR_RQST) ||
		eplm.orderbook.C_slm_flg == string(util.SLTP_ORDR_RQST) {
		eplm.st_ord_snd_rqst = &models.StOrdRqst{}
		eplm.st_ord_snd_rqst.LMsgTyp = util.LIMIT_MARKET_ORD

		eplm.st_ord_snd_rqst.LScripCd = int64(eplm.nse_contract.L_token_id)
		eplm.st_ord_snd_rqst.LMsgTag1 = int64(eplm.xchngbook.L_ord_seq)

		if eplm.xchngbook.C_req_typ == string(util.NEW) {
			eplm.st_ord_snd_rqst.LQty = int64(math.Abs(float64(eplm.xchngbook.L_ord_tot_qty)))

		} else if eplm.xchngbook.C_req_typ == util.MODIFY {
			l_mdfctn_cnt = int64(eplm.xchngbook.L_mdfctn_cntr)
			// c_lmt_mrkt_sl_flg = eplm.xchngbook.C_slm_flg

			query := `
				SELECT FXB_ORDR_TOT_QTY 
				FROM FXB_FO_XCHNG_BOOK 
				WHERE FXB_ORDR_RFRNC = $1 
				AND fxb_mdfctn_cntr = (
					SELECT MAX(fxb_mdfctn_cntr) 
					FROM FXB_FO_XCHNG_BOOK 
					WHERE FXB_PLCD_STTS = 'A' 
					AND FXB_ORDR_RFRNC = $2 
					AND fxb_mdfctn_cntr < $3
				)`
			err := eplm.Db.Exec(query, eplm.xchngbook.C_ordr_rfrnc, eplm.xchngbook.C_ordr_rfrnc, l_mdfctn_cnt).Scan(&l_previous_qty)
			if err != nil {
				log.Printf("Error counting records: %v", err)
				eplm.LoggerManager.LogError(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] [Error:Error counting records: %v", err)
				return -1

			}

			// Get the executed quantity.
			query2 := `
				SELECT COALESCE(SUM(FTD_EXCTD_QTY), 0) 
				FROM FTD_FO_TRD_DTLS 
				WHERE FTD_ORDR_RFRNC = $1`
			err = eplm.Db.Exec(query2, eplm.xchngbook.C_ordr_rfrnc).Scan(&l_exctd_qty)
			if err != nil {
				log.Fatalf("Failed to execute query2: %v", err)
				eplm.LoggerManager.LogError(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] [Error:Error counting records: %v", err)

			}
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_previous_qty :%ld:", l_previous_qty)
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_exctd_qty :%ld:", l_exctd_qty)
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_ord_tot_qty :%ld:", eplm.xchngbook.L_ord_tot_qty)
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_lmt_mrkt_sl_flg :%ld:", c_lmt_mrkt_sl_flg)

			l_modified_qty = int64(eplm.xchngbook.L_ord_tot_qty - int32(l_previous_qty))
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_modified_qty :%ld:", l_modified_qty)

			if c_lmt_mrkt_sl_flg == "S" {
				eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] Inside Stop Loss Order Condition")

				query3 := `
					SELECT FOD_STP_LSS_TGR 
					FROM FOD_FO_ORDR_DTLS 
					WHERE FOD_ORDR_RFRNC = $1`
				err = eplm.Db.Exec(query3, eplm.xchngbook.C_ordr_rfrnc).Scan(&l_stp_loss_trgr)
				if err != nil {
					eplm.LoggerManager.LogError(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] [Failed to execute query3: %v", err)
					return -1
				}
				eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] Stop Loss Trigger Price Is :%ld:", l_stp_loss_trgr)
			}
		} else if eplm.xchngbook.C_req_typ == util.CANCEL {
			eplm.st_ord_snd_rqst.LQty = 0
		}
		// if eplm.xchngbook.C_req_typ == util.CANCEL || eplm.xchngbook.C_req_typ == util.MODIFY {

		// 	query := `
		// 	SELECT FOD_LST_ACT_REF
		// 	FROM FOD_FO_ORDR_DTLS
		// 	WHERE FOD_ORDR_RFRNC = $1`
		// 	err := eplm.Db.Exec(query, eplm.xchngbook.C_ordr_rfrnc).Scan(&v_ack_number)
		// 	if err != nil {
		// eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] Error counting records: %v", err)
		// eplm.LoggerManager.LogError(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] [Error while fetching ack number")
		// // 		return -1
		// // 	}

		// eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] ack number: %v", err)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse]  l_exctd_qty :%ld:", l_exctd_qty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] :%ld:", eplm.xchngbook.L_ord_tot_qty)

		eplm.st_ord_snd_rqst.LRevealedQty = int64(eplm.xchngbook.L_ord_tot_qty) - l_exctd_qty
		if eplm.xchngbook.C_slm_flg == string(util.MARKET_ORDR_RQST) {
			eplm.st_ord_snd_rqst.LRate = 0
		} else {
			eplm.st_ord_snd_rqst.LRate = int64(eplm.xchngbook.L_ord_lmt_rt)
		}

		eplm.st_ord_snd_rqst.LResrvdFld2 = 0
		eplm.st_ord_snd_rqst.LResrvdFld3 = 0
		eplm.st_ord_snd_rqst.LFiller1 = 0
		eplm.st_ord_snd_rqst.LFiller2 = 0
		eplm.st_ord_snd_rqst.LMsgTag2 = 0

		if eplm.xchngbook.C_req_typ == string(util.NEW) {
			eplm.st_ord_snd_rqst.LlOrdrId = 0
		} else {
			eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse]  Inside ELSS part of rqst Typ")
			eplm.st_ord_snd_rqst.LlOrdrId, _ = strconv.ParseInt(eplm.orderbook.C_xchng_ack, 10, 64)
		}
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse]  Order id after parsing :%ld:", eplm.st_ord_snd_rqst.LlOrdrId)

		eplm.st_ord_snd_rqst.LlLocationId, _ = strconv.ParseInt(c_location_id, 10, 64)
		eplm.st_ord_snd_rqst.LFiller1 = 0
		eplm.st_ord_snd_rqst.LFiller2 = 0
		eplm.st_ord_snd_rqst.LFiller3 = 0

		copy(eplm.st_ord_snd_rqst.CClientId[:], eplm.orderbook.C_cln_mtch_accnt)
		copy(eplm.st_ord_snd_rqst.CResrvdFld[:], "0")
		copy(eplm.st_ord_snd_rqst.CMsgTag[:], " ")
		copy(eplm.st_ord_snd_rqst.CFiller6[:], " ")

		if eplm.xchngbook.C_req_typ == string(util.NEW) {
			eplm.st_ord_snd_rqst.COrdrActnCd = util.ADD_LMT_MRKT_ORDR
		} else if eplm.xchngbook.C_req_typ == util.MODIFY {
			eplm.st_ord_snd_rqst.COrdrActnCd = util.UPD_LMT_MRKT_ORDR
		} else if eplm.xchngbook.C_req_typ == util.CANCEL {
			eplm.st_ord_snd_rqst.COrdrActnCd = util.DEL_LMT_MRKT_ORDR
		}

		if eplm.orderbook.C_ordr_flw == "B" {
			eplm.st_ord_snd_rqst.COrdrBuySellFlg = util.BSE_BUY
		} else if eplm.orderbook.C_ordr_flw == "S" {
			eplm.st_ord_snd_rqst.COrdrBuySellFlg = util.BSE_SELL
		}

		if eplm.xchngbook.C_slm_flg == "L" {
			if l_stp_loss_trgr != 0 {
				eplm.st_ord_snd_rqst.COrdTyp = util.SLTP_ORDR
			} else {
				eplm.st_ord_snd_rqst.COrdTyp = util.LIMIT_ORDR

			}
			eplm.st_ord_snd_rqst.LTrigrRate = 0
		} else if eplm.xchngbook.C_slm_flg == "M" {
			if l_stp_loss_trgr != 0 {
				eplm.st_ord_snd_rqst.COrdTyp = util.SLTP_ORDR
				eplm.st_ord_snd_rqst.LRate = 0
			} else {
				eplm.st_ord_snd_rqst.COrdTyp = util.MARKET_ORDR
			}
			eplm.st_ord_snd_rqst.LTrigrRate = 0
		} else if eplm.xchngbook.C_slm_flg == "S" {
			eplm.st_ord_snd_rqst.COrdTyp = util.SLTP_ORDR
			eplm.st_ord_snd_rqst.LRate = int64(eplm.xchngbook.L_stp_lss_tgr)
		}
		eplm.st_ord_snd_rqst.CFiller7 = '0'
		fmt.Println(eplm.orderbook.C_cln_mtch_accnt)

		query := `
    SELECT ICD_CUST_TYPE
    FROM ICD_INFO_CLIENT_DTLS
    JOIN IAI_INFO_ACCOUNT_INFO ON ICD_INFO_CLIENT_DTLS.ICD_SERIAL_NO = IAI_INFO_ACCOUNT_INFO.IAI_SERIAL_NO
    WHERE IAI_MATCH_ACCOUNT_NO = $1;
`
		err := eplm.Db.Raw(query, eplm.orderbook.C_cln_mtch_accnt).Scan(&sqlIcdCustType).Error
		fmt.Println("-----------------", sqlIcdCustType)
		if err != nil {
			log.Printf("Failed to execute query: %v", err)
			eplm.LoggerManager.LogError(eplm.ServiceName, " [FnPAckOrdnryOrdToBse] [Failed to execute query: %v", err)
			return -1
		}
		fmt.Println(eplm.st_ord_snd_rqst)
		// if eplm.st_ord_snd_rqst == nil {
		// 	eplm.st_ord_snd_rqst = &models.StOrdRqst{}
		// }
		// eplm.st_ord_snd_rqst.SClientTyp = 0
		if sqlIcdCustType == "NRI" {
			if eplm.orderbook.C_ordr_flw == "B" {

				eplm.st_ord_snd_rqst.SClientTyp = util.CA_CLASS_NRI_BUY_ORD
			} else if eplm.orderbook.C_ordr_flw == "S" {

				eplm.st_ord_snd_rqst.SClientTyp = util.CA_CLASS_NRI_SELL_ORD

			}
		} else {

			eplm.st_ord_snd_rqst.SClientTyp = util.CA_CLASS_CLIENT

		}

		if eplm.xchngbook.C_ord_typ == "I" {
			fmt.Println("-----------------")
			eplm.st_ord_snd_rqst.SRetention = util.IMMEDIATE // IOC Order Validity
		} else {

			eplm.st_ord_snd_rqst.SRetention = util.END_OF_SSSN
		}
		if eplm.sthdr == nil {
			eplm.sthdr = &models.St_bfo_header{}
		}
		// eplm.sthdr.L_slot_no = 0
		eplm.sthdr.L_slot_no = util.REQ_SLOT_NO

		eplm.sthdr.L_message_length = int64(unsafe.Sizeof(eplm.st_ord_snd_rqst) - unsafe.Sizeof(eplm.sthdr))

		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] **** Before Converation ")
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_msg_typ  :%ld:", eplm.st_ord_snd_rqst.LMsgTyp)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_scrip_cd :%ld:", eplm.st_ord_snd_rqst.LScripCd)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_msg_tag1 :%ld:", eplm.st_ord_snd_rqst.LMsgTag1)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_qty :%ld:", eplm.st_ord_snd_rqst.LQty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_revealed_qty :%ld:", eplm.st_ord_snd_rqst.LRevealedQty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_trigr_rate :%ld:", eplm.st_ord_snd_rqst.LTrigrRate)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] ll_ordr_id :%ld:", eplm.st_ord_snd_rqst.LlOrdrId)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] ll_location_id :%d:", eplm.st_ord_snd_rqst.LlLocationId)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_client_typ :%d:", eplm.st_ord_snd_rqst.SClientTyp)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_mrkt_protection :%d:", eplm.st_ord_snd_rqst.SMrktProtection)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_retention :%d:", eplm.st_ord_snd_rqst.SRetention)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_slot_no :%ld:", eplm.sthdr.L_slot_no)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_message_length :%ld:", eplm.sthdr.L_message_length)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ordr_actn_cd :%ld:", eplm.st_ord_snd_rqst.COrdrActnCd)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ordr_buysell_flg :%ld:", eplm.st_ord_snd_rqst.COrdrBuySellFlg)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ord_typ :%ld:", eplm.st_ord_snd_rqst.COrdTyp)

		// Converting to Network Byte
		fmt.Println(eplm.st_ord_snd_rqst.LMsgTyp)
		eplm.st_ord_snd_rqst.LMsgTyp = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LMsgTyp)
		eplm.st_ord_snd_rqst.LScripCd = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LMsgTag1 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LQty = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LRevealedQty = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LRate = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LTrigrRate = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LResrvdFld2 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LResrvdFld3 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LFiller1 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LFiller2 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LFiller3 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LMsgTag2 = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.st_ord_snd_rqst.LMsgTag2)
		eplm.st_ord_snd_rqst.SFiller4 = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SFiller4)
		eplm.st_ord_snd_rqst.SFiller5 = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SFiller5)
		eplm.st_ord_snd_rqst.SClientTyp = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SClientTyp)
		eplm.st_ord_snd_rqst.SMrktProtection = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SMrktProtection)
		eplm.st_ord_snd_rqst.SRetention = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SRetention)
		eplm.st_ord_snd_rqst.SFiller8 = eplm.OCM.ConvertInt16ToNetworkOrder(eplm.st_ord_snd_rqst.SFiller8)
		eplm.sthdr.L_slot_no = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.sthdr.L_slot_no)
		eplm.sthdr.L_message_length = eplm.OCM.ConvertInt64ToNetworkOrder(eplm.sthdr.L_message_length)

		//Convertion of values in exchange specific format

		eplm.st_ord_snd_rqst.LMsgTyp = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LMsgTyp)
		eplm.st_ord_snd_rqst.LScripCd = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LScripCd)
		eplm.st_ord_snd_rqst.LMsgTag1 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LMsgTag1)
		eplm.st_ord_snd_rqst.LQty = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LQty)
		eplm.st_ord_snd_rqst.LRevealedQty = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LRevealedQty)
		eplm.st_ord_snd_rqst.LRate = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LRate)
		eplm.st_ord_snd_rqst.LTrigrRate = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LTrigrRate)
		eplm.st_ord_snd_rqst.LResrvdFld2 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LResrvdFld2)
		eplm.st_ord_snd_rqst.LResrvdFld3 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LResrvdFld3)
		eplm.st_ord_snd_rqst.LFiller1 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LFiller1)
		eplm.st_ord_snd_rqst.LFiller2 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LFiller2)
		eplm.st_ord_snd_rqst.LMsgTag2 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LMsgTag2)
		eplm.st_ord_snd_rqst.LlOrdrId = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LlOrdrId)
		eplm.st_ord_snd_rqst.LlLocationId = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LlLocationId)
		eplm.st_ord_snd_rqst.LFiller3 = eplm.TCUM.FnSwapLong(eplm.st_ord_snd_rqst.LFiller3)
		eplm.st_ord_snd_rqst.SFiller4 = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SFiller4)
		eplm.st_ord_snd_rqst.SFiller5 = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SFiller5)
		eplm.st_ord_snd_rqst.SClientTyp = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SClientTyp)
		eplm.st_ord_snd_rqst.SMrktProtection = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SMrktProtection)
		eplm.st_ord_snd_rqst.SRetention = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SRetention)
		eplm.st_ord_snd_rqst.SFiller8 = eplm.TCUM.FnSwapShort(eplm.st_ord_snd_rqst.SFiller8)
		eplm.sthdr.L_slot_no = eplm.TCUM.FnSwapLong(eplm.sthdr.L_slot_no)
		eplm.sthdr.L_message_length = eplm.TCUM.FnSwapLong(eplm.sthdr.L_message_length)

		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] **** After Converation ")
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_msg_typ  :%ld:", eplm.st_ord_snd_rqst.LMsgTyp)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_scrip_cd :%ld:", eplm.st_ord_snd_rqst.LScripCd)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_msg_tag1 :%ld:", eplm.st_ord_snd_rqst.LMsgTag1)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_qty :%ld:", eplm.st_ord_snd_rqst.LQty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_revealed_qty :%ld:", eplm.st_ord_snd_rqst.LRevealedQty)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_trigr_rate :%ld:", eplm.st_ord_snd_rqst.LTrigrRate)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] ll_ordr_id :%ld:", eplm.st_ord_snd_rqst.LlOrdrId)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] ll_location_id :%d:", eplm.st_ord_snd_rqst.LlLocationId)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_client_typ :%d:", eplm.st_ord_snd_rqst.SClientTyp)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_mrkt_protection :%d:", eplm.st_ord_snd_rqst.SMrktProtection)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] s_retention :%d:", eplm.st_ord_snd_rqst.SRetention)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_slot_no :%ld:", eplm.sthdr.L_slot_no)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] l_message_length :%ld:", eplm.sthdr.L_message_length)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ordr_actn_cd :%ld:", eplm.st_ord_snd_rqst.COrdrActnCd)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ordr_buysell_flg :%ld:", eplm.st_ord_snd_rqst.COrdrBuySellFlg)
		eplm.LoggerManager.LogInfo(eplm.ServiceName, "[FnPAckOrdnryOrdToBse] c_ord_typ :%ld:", eplm.st_ord_snd_rqst.COrdTyp)

	}
	eplm.st_req_q_data = &models.St_req_q_data{}
	eplm.st_req_q_data.L_msg_type = util.LIMIT_MARKET_ORD
	fmt.Println(eplm.st_ord_snd_rqst)
	fmt.Println("**************************** FnPAckOrdnryOrdToBse ends")
	var buf bytes.Buffer
	if err := binary.Write(&buf, binary.LittleEndian, *eplm.st_ord_snd_rqst); err != nil {
		log.Fatalf("Failed to serialize st_ord_snd_rqst: %v", err)
	}

	copy(eplm.st_req_q_data.St_exch_msg_data[:], buf.Bytes())
	fmt.Println(eplm.st_req_q_data)
	fmt.Println("**************************** FnPAckOrdnryOrdToBse ends")
	return 0

}
