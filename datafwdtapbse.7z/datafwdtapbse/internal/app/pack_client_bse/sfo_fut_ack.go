package pack_client_bse

import (
	"datafwdtapbse/internal/models"
	"datafwdtapbse/util"
	"datafwdtapbse/util/OrderConversion"
	"unsafe"

	"gorm.io/gorm"
)

type ExchngPackLibMstr struct {
	ServiceName     string
	xchngbook       *models.Vw_xchngbook
	orderbook       *models.Vw_orderbook
	pipe_mstr       *models.St_opm_pipe_mstr
	nse_contract    *models.Vw_nse_cntrct
	oe_reqres       *models.St_oe_reqres
	exch_msg        *models.St_exch_msg
	net_hdr         *models.St_net_hdr
	q_packet        *models.St_req_q_data
	int_header      *models.St_int_header
	contract_desc   *models.St_contract_desc
	order_flag      *models.St_order_flags
	st_ord_snd_rqst *models.StOrdRqst
	sthdr           *models.St_bfo_header
	OCM             *OrderConversion.OrderConversionManager
	cPanNo          [util.LEN_PAN]byte
	cLstActRef      [22]byte
	cEspID          [51]byte
	cAlgoID         [51]byte
	cSourceFlg      byte
	cPrgmFlg        byte
	cUserTypGlb     byte
	LoggerManager   *util.LoggerManager
	TrnscManager    *util.TransactionManager
	Pstnactn        *models.Vw_pstn_actn

	Mtype *int
	Db    *gorm.DB
}

var i_trnsctn int
var i_ip_len int
var i_op_len int
var c_cvr_prd_typ string = ""
var c_sys_msg string = ""
var l_sroll_diff_amt int64 = 0
var l_sroll_lss_amt int64 = 0
var c_expry_date_current_ordr string
var c_ordr_flow_phy string = ""
var c_sltp_ord_rfrnc string
var c_spl_flg string = ""

func (eplm *ExchngPackLibMstr) SFO_FUT_ACK() int {

	i_trnsctn = eplm.TrnscManager.FnBeginTran()
	if i_trnsctn == -1 {
		eplm.LoggerManager.LogError(eplm.ServiceName, " [sfo_fut_ack] Failed to begin transaction")
	}

	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [sfo_fut_ack] Stage 1")
	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [sfo_fut_ack] eplm.xchngbook.C_oprn_typ:%d:", eplm.xchngbook.C_oprn_typ)

	eplm.orderbook.C_ordr_rfrnc = eplm.xchngbook.C_ordr_rfrnc
	eplm.orderbook.C_oprn_typ = string(util.For_UPDATE)

	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [sfo_fut_ack] eplm.xchngbook.C_ordr_rfrnc:%d:", eplm.xchngbook.C_ordr_rfrnc)
	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [sfo_fut_ack] eplm.orderbook.C_ordr_rfrnc:%d:", eplm.orderbook.C_ordr_rfrnc)

	i_ip_len = int(unsafe.Sizeof(eplm.orderbook))
	i_op_len = int(unsafe.Sizeof(eplm.orderbook))

	eplm.orderbook.C_rout_crt = ""
	eplm.LoggerManager.LogInfo(eplm.ServiceName, " [sfo_fut_ack] Stage 2")

	query := `
		SELECT 
			fod_prdct_typ AS c_cvr_prd_typ, 
			CASE 
				WHEN FOD_EOS_FLG = 'M' THEN 'MY_EOS' 
				WHEN FOD_EOS_FLG = 'N' THEN 'EOS' 
				WHEN FOD_EOS_FLG = 'E' THEN 'EXCPT_EOS' 
				WHEN FOD_EOS_FLG = 'S' THEN 'SYS_EVENT' 
				WHEN FOD_EOS_FLG = 'X' THEN 'X' 
			END AS c_sys_msg,
			CASE 
				WHEN FOD_EOS_FLG = 'M' THEN FOD_CHANNEL 
				WHEN FOD_EOS_FLG = 'E' THEN 'SYS' 
				WHEN FOD_EOS_FLG = 'N' THEN 'SYS' 
				WHEN FOD_EOS_FLG = 'S' THEN 'SYS' 
				ELSE FOD_CHANNEL 
			END AS c_channel,
			COALESCE(FOD_SROLL_DIFF_AMT, 0) AS l_sroll_diff_amt,
			COALESCE(FOD_SROLL_LSS_AMT, 0) AS l_sroll_lss_amt,
			FOD_SPL_FLAG AS c_spl_flg,
			FOD_EXPRY_DT AS c_expry_date_current_ordr,
			FOD_ORDR_FLW AS c_ordr_flow_phy,
			COALESCE(FOD_SLTP_ORDR_RFRNC, '*') AS c_sltp_ord_rfrnc
		FROM FOD_FO_ORDR_DTLS
		WHERE fod_ordr_rfrnc = ?`

	row := eplm.Db.Raw(query, eplm.orderbook.C_ordr_rfrnc).Row()

	err := row.Scan(
		&c_cvr_prd_typ, &c_sys_msg, eplm.Pstnactn.C_channel, &l_sroll_diff_amt, &l_sroll_lss_amt, &c_spl_flg,
		&c_expry_date_current_ordr, &c_ordr_flow_phy, &c_sltp_ord_rfrnc)

	if err != nil {
		return -1
	}
	return 0

}
