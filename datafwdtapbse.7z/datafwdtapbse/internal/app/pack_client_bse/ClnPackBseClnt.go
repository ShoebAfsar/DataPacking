package pack_client_bse

import (
	PackingService "datafwdtapbse/internal/app/PackingService"
	"datafwdtapbse/internal/database"
	"datafwdtapbse/internal/models"
	"datafwdtapbse/util"
	"datafwdtapbse/util/OrderConversion"

	"datafwdtapbse/util/TypeConversion"
	MessageQueue "datafwdtapbse/util/messageQueue"
	"fmt"
	"log"
	"strconv"
	"strings"

	"gorm.io/gorm"
)

type ClnPackClntManager struct {
	LoggerManager   *util.LoggerManager
	ServiceName     string
	Xchngbook       *models.Vw_xchngbook
	Orderbook       *models.Vw_orderbook
	VmContract      *models.Vw_contract
	VwNseContract   *models.Vw_nse_cntrct
	PackingService  *PackingService.ExchngPackLibMaster
	st_ord_snd_rqst *models.StOrdRqst
	sthdr           *models.St_bfo_header
	OCM             *OrderConversion.OrderConversionManager

	// Contract                 *models.Vw_contract
	Nse_contract             *models.Vw_nse_cntrct // we are updating it in 'fn_get_ext_cnt'
	Oe_reqres                *models.St_oe_reqres
	Pipe_mstr                *models.St_opm_pipe_mstr
	Enviroment_manager       *util.EnvironmentManager
	Transaction_manager      *util.TransactionManager
	Message_queue_manager    *MessageQueue.MessageQueueManager
	Exch_msg                 *models.St_exch_msg
	Net_hdr                  *models.St_net_hdr
	Q_packet                 *models.St_req_q_data
	Int_header               *models.St_int_header
	Contract_desc            *models.St_contract_desc
	Order_flag               *models.St_order_flags
	Order_conversion_manager *OrderConversion.OrderConversionManager
	CPanNo                   string // Pan number, initialized in the 'fnRefToOrd' method
	CLstActRef               string // Last activity reference, initialized in the 'fnRefToOrd' method
	CEspID                   string // ESP ID, initialized in the 'fnRefToOrd' method
	CAlgoID                  string // Algorithm ID, initialized in the 'fnRefToOrd' method
	CSourceFlg               string // Source flag, initialized in the 'fnRefToOrd' method
	CPrgmFlg                 string
	Max_Pack_Val             int
	Config_manager           *database.ConfigManager
	TCUM                     *TypeConversion.TypeConversionUtilManager
	MtypeWrite               *int
	Args                     []string
	Db                       *gorm.DB
	QueueId                  int
	InitialQId               *int
	GlobalQId                *int

	// ---------------------------------------
	Fod_iXchngAck int64
	Fod_c_cp_code string
	Fod_c_ucc_cd  string
	// XchngBook VAlues ---------------------
	// sqlCNxtTrdDate      string
	// sqlCXchngCd         string
	// sqlCPipeId          string
	sql_c_xchng_ctcl_id string
}

var exg_excr_mkt_stts string
var li_max_q int64
var exg_crrnt_stts string
var li_cnt_q = 0
var c_expiry_dt string
var i_in_tran_flag int = 0

func (cpcm *ClnPackClntManager) Fn_bat_init() int {
	var temp_str string
	var resultTmp int
	cpcm.ServiceName = "cln_pack_clnt_bse"
	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Entering Fn_bat_init")

	if len(cpcm.Args) < 7 {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: insufficient arguments provided %d", len(cpcm.Args))
		return -1
	}

	cpcm.Xchngbook.C_pipe_id = cpcm.Args[3]

	cpcm.Message_queue_manager.LoggerManager = cpcm.LoggerManager
	var tempQResult int

	tempQResult = cpcm.Message_queue_manager.CreateQueue(cpcm.InitialQId)
	fmt.Println("=====================================")
	if tempQResult == -1 {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: Returning from 'CreateQueue' with an Error... %s")
		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init]  Exiting from function")
	} else {
		*cpcm.GlobalQId = tempQResult
		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Created Message Queue SuccessFully With InitialQueueId: %d", *cpcm.InitialQId)
	}

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Copied pipe ID from cpcm.Args[3]: %s", cpcm.Xchngbook.C_pipe_id)

	queryForOpm_Xchng_Cd := `SELECT opm_xchng_cd,opm_max_pnd_ord
				FROM opm_ord_pipe_mstr
				WHERE opm_pipe_id = ?`

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Executing query to fetch exchange code with pipe ID: %s", cpcm.Xchngbook.C_pipe_id)

	row := cpcm.Db.Raw(queryForOpm_Xchng_Cd, cpcm.Xchngbook.C_pipe_id).Row()
	temp_str = ""

	err := row.Scan(&temp_str, &li_max_q)
	if err != nil {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: scanning row for exchange code: %v", cpcm.Xchngbook.C_xchng_cd, err)
		return -1
	}

	cpcm.Xchngbook.C_xchng_cd = temp_str
	temp_str = ""
	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Exchange code fetched: %s", cpcm.Xchngbook.C_xchng_cd)

	queryForTraderAndBranchID := `SELECT OPM_TRDR_ID, OPM_BRNCH_ID
				FROM OPM_ORD_PIPE_MSTR
				WHERE OPM_XCHNG_CD = ? AND OPM_PIPE_ID = ?`

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Executing query to fetch trader and branch ID with exchange code: %s and pipe ID: %s", cpcm.Xchngbook.C_xchng_cd, cpcm.Xchngbook.C_pipe_id)

	rowQueryForTraderAndBranchID := cpcm.Db.Raw(queryForTraderAndBranchID, cpcm.Xchngbook.C_xchng_cd, cpcm.Xchngbook.C_pipe_id).Row()

	errQueryForTraderAndBranchID := rowQueryForTraderAndBranchID.Scan(&cpcm.Pipe_mstr.C_opm_trdr_id, &cpcm.Pipe_mstr.L_opm_brnch_id)
	if errQueryForTraderAndBranchID != nil {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] Error scanning row for trader and branch ID: %v", errQueryForTraderAndBranchID)
		return -1
	}

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] fetched trader ID: %s and branch ID : %d", cpcm.Pipe_mstr.C_opm_trdr_id, cpcm.Pipe_mstr.L_opm_brnch_id)

	// Fetch modification trade date from 'exg_xchng_mstr'

	queryFor_exg_nxt_trd_dt := `SELECT exg_nxt_trd_dt,
				exg_brkr_id,exg_ctcl_id
				FROM exg_xchng_mstr
				WHERE exg_xchng_cd = ?`

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Fetching trade date and broker ID with exchange code: %s", cpcm.Xchngbook.C_xchng_cd)
	row2 := cpcm.Db.Raw(queryFor_exg_nxt_trd_dt, cpcm.Xchngbook.C_xchng_cd).Row()

	err2 := row2.Scan(&temp_str, &cpcm.Pipe_mstr.C_xchng_brkr_id, &cpcm.sql_c_xchng_ctcl_id)
	if err2 != nil {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: scanning trade date and broker ID: %v", err2)
		return -1
	}

	cpcm.Xchngbook.C_mod_trd_dt = temp_str

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Fetched trade date : %s and broker ID : %s", cpcm.Xchngbook.C_mod_trd_dt, cpcm.Pipe_mstr.C_xchng_brkr_id)

	cpcm.Xchngbook.L_ord_seq = 0 // I am initially setting it to '0' because it was set that way in 'fn_bat_init' and I have not seen it getting changed anywhere. If I find it being changed somewhere, I will update it accordingly.

	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] L_ord_seq initialized to %d", cpcm.Xchngbook.L_ord_seq)

	//here we are setting the S_user_typ_glb of 'St_opm_pipe_mstr' from the configuration file
	userTypeStr := cpcm.Enviroment_manager.GetProcessSpaceValue("UserSettings", "USER_TYPE")
	userType, err := strconv.Atoi(userTypeStr)
	if err != nil {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: Failed to convert UserType '%s' to integer: %v", userTypeStr, err)

	}
	cpcm.Pipe_mstr.S_user_typ_glb = userType

	// finally we are calling the CLN_PACK_CLNT function (service)
	resultTmp = cpcm.CLN_BSE_PACK_CLNT()
	if resultTmp != 0 {
		cpcm.LoggerManager.LogError(cpcm.ServiceName, " [Fn_bat_init] [Error: CLN_PACK_CLNT failed with result code: %d", resultTmp)
		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] [Error: Returning to main from fn_bat_init")
		return -1
	}
	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [Fn_bat_init] Exiting Fn_bat_init")
	return 0

}

func (cpcm *ClnPackClntManager) CLN_BSE_PACK_CLNT() int {
	var resultTmp int
	cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] Entering CLN_BSE_PACK_CLNT")
	for {
		resultTmp = cpcm.Transaction_manager.FnBeginTran()
		if resultTmp == -1 {
			cpcm.LoggerManager.LogError(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] [Error: Transaction begin failed")
			return -1
		}
		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] Transaction started with type: %d", cpcm.Transaction_manager.TranType)
		resultTmp = cpcm.FnGetNxtBseRec()
		if resultTmp != 0 {
			cpcm.LoggerManager.LogError(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] [Error: failed in getting the next record returning with result code: %d", resultTmp)
			if cpcm.Transaction_manager.FnAbortTran() == -1 {
				cpcm.LoggerManager.LogError(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] [Error: Transaction abort failed")
				return -1
			}
			cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] Exiting CLN_BSE_PACK_CLNT with error")
			return -1
		}

		if cpcm.Transaction_manager.FnCommitTran() == -1 {
			cpcm.LoggerManager.LogError(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] [Error: Transaction commit failed")
			return -1
		}
		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [CLN_BSE_PACK_CLNT] Transaction committed successfully")
		cpcm.Message_queue_manager.ServiceName = cpcm.ServiceName

		mtypeWrite := *cpcm.MtypeWrite
		
		if cpcm.Message_queue_manager.WriteToQueue(mtypeWrite, cpcm.Q_packet) != 0 {
			cpcm.LoggerManager.LogError(cpcm.ServiceName, " [CLN_PACK_CLNT] [Error:  Failed to write to queue with message type %d", mtypeWrite)
			return -1
		}

		cpcm.LoggerManager.LogInfo(cpcm.ServiceName, " [CLN_PACK_CLNT] Successfully wrote to queue with message type %d", mtypeWrite)

	}

}

func (CPCM *ClnPackClntManager) FnGetNxtBseRec() int {

	var li_count int64
	var queueCheckFlag int
	var orderMarketStatus bool
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] Entering FnGetNxtBseRec")

	fmt.Println("Printing values of sqlCNxtTrdDate, sqlCXchngCd, sqlCPipeId :", CPCM.Xchngbook.C_mod_trd_dt, CPCM.Xchngbook.C_xchng_cd, CPCM.Xchngbook.C_pipe_id)
	if int64(li_cnt_q) >= li_max_q || queueCheckFlag == 1 {
		err := CPCM.Db.Table("fxb_fo_xchng_book").
			Where("fxb_mod_trd_dt = ? AND fxb_xchng_cd = ? AND fxb_pipe_id = ? AND fxb_plcd_stts = ?",
				CPCM.Xchngbook.C_mod_trd_dt,
				CPCM.Xchngbook.C_xchng_cd,
				CPCM.Xchngbook.C_pipe_id,
				"Q").
			Count(&li_count).Error

		if err != nil {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: Error counting records: %v", err)
			return -1
		}

		log.Printf("Queue check count: %d", li_count)

		if li_count >= li_max_q {
			queueCheckFlag = 1
			log.Printf("Number of orders in queued state [%d] exceeds max allowed [%d] for pipe: %s", li_cnt_q, li_max_q, CPCM.Xchngbook.C_pipe_id)
			CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] OVERLOAD")
			return -1
		}
		li_cnt_q = 0
		queueCheckFlag = 0
	}

	// CPCM.Xchngbook.C_xchng_cd = sqlCXchngCd
	// CPCM.Xchngbook.C_pipe_id = sqlCPipeId
	// CPCM.Xchngbook.C_mod_trd_dt = sqlCNxtTrdDate

	CPCM.Xchngbook.C_oprn_typ = string(util.FOR_NORM)
	log.Println("In Normal Market selection")
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] In Normal Market selection")

	resultTmp := CPCM.FnSeqToBseOmd()
	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: Failed to fetch data into eXchngbook structure")
		return -1
	}

	if CPCM.Xchngbook.C_plcd_stts != string(util.REQUESTED) {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] data cancelled")
		return -1
	}
	queryForExg_crrnt_stts := `SELECT exg_crrnt_stts,exg_exrc_mkt_stts 
				FROM exg_xchng_mstr
				WHERE exg_xchng_cd = ?`

	row := CPCM.Db.Raw(queryForExg_crrnt_stts, CPCM.Xchngbook.C_xchng_cd).Row()

	err := row.Scan(&exg_crrnt_stts, &exg_excr_mkt_stts)
	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [Fn_bat_init] [Error: scanning row for exchange code: %v", CPCM.Xchngbook.C_xchng_cd, err)
		return -1
	}
	if exg_crrnt_stts == string(util.EXCHANGE_OPEN) {
		orderMarketStatus = true
	}

	if !orderMarketStatus {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] data skipped")
		return -1
	}

	CPCM.Orderbook.C_ordr_rfrnc = CPCM.Xchngbook.C_ordr_rfrnc
	CPCM.Orderbook.C_oprn_typ = string(util.FOR_SNDCLNT)
	fmt.Println(CPCM.Orderbook.C_ordr_rfrnc)
	log.Println("Calling SFO_REF_TO_ORD for normal order")

	resultTmp = CPCM.FnBseRefToOrd()
	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error:Error: Failed to fetch data into orderbook structure")
		return -1
	}
	fmt.Println("CPCM.Orderbook.L_mdfctn_cntr != CPCM.Xchngbook.L_mdfctn_cntr", CPCM.Orderbook.L_mdfctn_cntr, CPCM.Xchngbook.L_mdfctn_cntr)

	if CPCM.Orderbook.L_mdfctn_cntr != CPCM.Xchngbook.L_mdfctn_cntr {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] data cancelled")
		return -1
	}

	CPCM.Xchngbook.C_plcd_stts = string(util.QUEUED)
	CPCM.Xchngbook.C_oprn_typ = string(util.UPDATION_ON_ORDER_FORWARDING)

	log.Println("Calling SFO_UPD_XCHNGBK for normal order")

	resultTmp = CPCM.FnUpdBseXchngBook()
	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: failed to update the status in Xchngbook")
		return -1
	}

	log.Println("After Calling SFO_UPD_XCHNGBK for normal order")

	CPCM.Orderbook.C_ordr_stts = string(util.QUEUED)
	CPCM.Orderbook.C_oprn_typ = string(util.UPDATE_ORDER_STATUS)
	log.Println("Calling SFO_UPD_ORDRBK for normal order")

	resultTmp = CPCM.FnUpdBseOrdrBook()

	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: failed to update the status in Order book")
		return -1
	}
	if CPCM.Orderbook == nil {
		fmt.Println("CPCM.Orderbook is nil")
	}
	CPCM.VmContract = &models.Vw_contract{}
	fmt.Println(CPCM.Orderbook.C_xchng_cd,
		CPCM.Orderbook.C_prd_typ,
		CPCM.Orderbook.C_undrlyng,
		CPCM.Orderbook.C_expry_dt,
		CPCM.Orderbook.C_exrc_typ,
		CPCM.Orderbook.C_opt_typ,
		CPCM.Orderbook.L_strike_prc,
		CPCM.Orderbook.C_ctgry_indstk)
	CPCM.VmContract.C_xchng_cd = CPCM.Orderbook.C_xchng_cd
	CPCM.VmContract.C_prd_typ = CPCM.Orderbook.C_prd_typ
	CPCM.VmContract.C_undrlyng = CPCM.Orderbook.C_undrlyng
	CPCM.VmContract.C_expry_dt = CPCM.Orderbook.C_expry_dt
	CPCM.VmContract.C_exrc_typ = CPCM.Orderbook.C_exrc_typ
	CPCM.VmContract.C_opt_typ = CPCM.Orderbook.C_opt_typ
	CPCM.VmContract.L_strike_prc = CPCM.Orderbook.L_strike_prc
	CPCM.VmContract.C_ctgry_indstk = CPCM.Orderbook.C_ctgry_indstk
	// CPCM.VmContract.L_ca_lvl = CPCM.Orderbook.L_ca_lvl

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] Converting contract information to exchange format")

	resultTmp = CPCM.FnGetBseScripCd()
	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: Recieved error by calling FnGetBseScripCd function")
		return -1
	}
	log.Println("After converting contract information to exchange format")

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] Packing Ordinary order STARTS")

	if CPCM.VwNseContract.L_token_id == 0 {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetNxtBseRec] The token id for Ordinarty order is : %ld", CPCM.VwNseContract.L_token_id)
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [fnGetNxtRec] [Error: token id is not avialable so we are calling 'FnBseRjctRcrd' ")
		resultTmp = CPCM.FnBseRjctRcrd()
		if resultTmp != 0 {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, " [fnGetNxtRec] [Error: returned from 'FnBseRjctRcrd' with Error")
			CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [fnGetNxtRec] Exiting from 'FnBseGetNxtRec' ")
			return -1
		}

	}
	fmt.Println(CPCM.Orderbook)
	eplm := PackingService.NewExchngPackLibMaster(
		CPCM.ServiceName,
		CPCM.Xchngbook,
		CPCM.Orderbook,
		CPCM.Pipe_mstr,
		CPCM.Nse_contract,
		CPCM.st_ord_snd_rqst,
		CPCM.sthdr,
		CPCM.OCM,
		// 	CPCM.Oe_reqres,
		// 	CPCM.Exch_msg,
		// 	CPCM.Net_hdr,
		// 	CPCM.Q_packet,
		// 	CPCM.Int_header,
		// 	CPCM.Contract_desc,
		// 	CPCM.Order_flag,
		// 	CPCM.Order_conversion_manager,
		// 	CPCM.CPanNo,
		// 	CPCM.CLstActRef,
		// 	CPCM.CEspID,
		// 	CPCM.CAlgoID,
		// 	CPCM.CSourceFlg,
		// 	CPCM.CPrgmFlg,
		CPCM.LoggerManager,
		CPCM.TCUM,
		CPCM.MtypeWrite,
		CPCM.Db,
	)

	fmt.Println("before calling fnPackbseOrdrec")
	resultTmp = eplm.FnPAckOrdnryOrdToBse()
	if resultTmp == -1 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnGetNxtBseRec] [Error: Recieved error by calling FnPackOrdnryOrdToBse function")
		return -1
	}
	fmt.Println(CPCM.Q_packet)
	fmt.Println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [fnGetNxtRec] Packing ordinary order ENDS")

	li_cnt_q++
	fmt.Println("Exiting fngetnxtbserec")
	return 0

}

func (CPCM *ClnPackClntManager) FnSeqToBseOmd() int {

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd] Entering FnSeqToBseOmd")

	query := `
		SELECT 
    fxb_ordr_rfrnc,
    fxb_lmt_mrkt_sl_flg,
    fxb_dsclsd_qty,
    fxb_ordr_tot_qty,
    fxb_lmt_rt,
    fxb_stp_lss_tgr,
	fxb_mdfctn_cntr,
    TO_CHAR(fxb_ordr_valid_dt, 'dd-mon-yyyy'),
    CASE WHEN fxb_ordr_type = 'V' THEN 'T' ELSE fxb_ordr_type END,
    fxb_sprd_ord_ind,
    fxb_rqst_typ,
    fxb_quote,
    TO_CHAR(fxb_qt_tm, 'dd-mon-yyyy hh24:mi:ss'),
    TO_CHAR(fxb_rqst_tm, 'dd-mon-yyyy hh24:mi:ss'),
    TO_CHAR(fxb_frwd_tm, 'dd-mon-yyyy hh24:mi:ss'),
    fxb_plcd_stts,
    fxb_rms_prcsd_flg,
    fxb_ors_msg_typ,
    TO_CHAR(fxb_ack_tm, 'dd-mon-yyyy hh24:mi:ss'),
    fxb_xchng_rmrks,
    fxb_ex_ordr_typ,
    fxb_xchng_cncld_qty,
    fxb_spl_flag,
    fxb_ordr_sqnc
FROM 
    FXB_FO_XCHNG_BOOK 
WHERE 
    fxb_xchng_cd = ?
    AND fxb_pipe_id = ?
    AND fxb_mod_trd_dt = TO_TIMESTAMP(?, 'yyyy-mm-dd"T"hh24:mi:ss"Z"')
    AND fxb_ordr_sqnc = (
        SELECT MIN(fxb_b.fxb_ordr_sqnc)
        FROM FXB_FO_XCHNG_BOOK fxb_b
        WHERE 
            fxb_b.fxb_xchng_cd = ?
            AND fxb_b.fxb_mod_trd_dt = TO_TIMESTAMP(?, 'yyyy-mm-dd"T"hh24:mi:ss"Z"')
            AND fxb_b.fxb_pipe_id = ?
            AND fxb_b.fxb_plcd_stts = 'R'
            AND COALESCE(fxb_b.fxb_rms_prcsd_flg, '*') != 'P'
    )
	`
	//every time I have to update fxb_plcd_stts='R'
	//update fxb_fo_xchng_book set fxb_plcd_stts='R' where fxb_xchng_cd='EX1';
	fmt.Println("]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]", CPCM.Xchngbook.C_xchng_cd,
		CPCM.Xchngbook.C_pipe_id,
		CPCM.Xchngbook.C_mod_trd_dt,
		CPCM.Xchngbook.C_xchng_cd,
		CPCM.Xchngbook.C_mod_trd_dt,
		CPCM.Xchngbook.C_pipe_id)

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd] Executing query")
	row := CPCM.Db.Raw(query,
		CPCM.Xchngbook.C_xchng_cd,
		CPCM.Xchngbook.C_pipe_id,
		CPCM.Xchngbook.C_mod_trd_dt,
		CPCM.Xchngbook.C_xchng_cd,
		CPCM.Xchngbook.C_mod_trd_dt,
		CPCM.Xchngbook.C_pipe_id).Row()

	err := row.Scan(
		&CPCM.Xchngbook.C_ordr_rfrnc,  // fxb_ordr_rfrnc
		&CPCM.Xchngbook.C_slm_flg,     // fxb_lmt_mrkt_sl_flg
		&CPCM.Xchngbook.L_dsclsd_qty,  // fxb_dsclsd_qty
		&CPCM.Xchngbook.L_ord_tot_qty, // fxb_ordr_tot_qty
		&CPCM.Xchngbook.L_ord_lmt_rt,  // fxb_lmt_rt
		&CPCM.Xchngbook.L_stp_lss_tgr,
		&CPCM.Xchngbook.L_mdfctn_cntr,
		&CPCM.Xchngbook.C_valid_dt,      // TO_CHAR(fxb_ordr_valid_dt, 'dd-mon-yyyy')
		&CPCM.Xchngbook.C_ord_typ,       // DECODE(fxb_ordr_type,'V','T',fxb_ordr_type)
		&CPCM.Xchngbook.C_sprd_ord_ind,  // fxb_sprd_ord_ind
		&CPCM.Xchngbook.C_req_typ,       // fxb_rqst_typ
		&CPCM.Xchngbook.L_quote,         // fxb_quote
		&CPCM.Xchngbook.C_qt_tm,         // TO_CHAR(fxb_qt_tm, 'dd-mon-yyyy hh24:mi:ss')
		&CPCM.Xchngbook.C_rqst_tm,       // TO_CHAR(fxb_rqst_tm, 'dd-mon-yyyy hh24:mi:ss')
		&CPCM.Xchngbook.C_frwrd_tm,      // TO_CHAR(fxb_frwd_tm, 'dd-mon-yyyy hh24:mi:ss')
		&CPCM.Xchngbook.C_plcd_stts,     // fxb_plcd_stts
		&CPCM.Xchngbook.C_rms_prcsd_flg, // fxb_rms_prcsd_flg
		&CPCM.Xchngbook.L_ors_msg_typ,   // fxb_ors_msg_typ
		&CPCM.Xchngbook.C_ack_tm,        // TO_CHAR(fxb_ack_tm, 'dd-mon-yyyy hh24:mi:ss')
		&CPCM.Xchngbook.C_xchng_rmrks,   // fxb_xchng_rmrks
		&CPCM.Xchngbook.C_ex_ordr_typ,   // fxb_ex_ordr_typ
		&CPCM.Xchngbook.L_xchng_can_qty, // fxb_xchng_cncld_qty
		&CPCM.Xchngbook.C_spl_flg,       // fxb_spl_flag
		&CPCM.Xchngbook.L_ord_seq,       // fxb_ordr_sqnc
	)

	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "[FnSeqToBseOmd] Error scanning row: %v", err)
		return -1
	}

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd] Data extracted and stored in the 'Xchngbook' structure:")
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_ordr_rfrnc:     %s", CPCM.Xchngbook.C_ordr_rfrnc)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_slm_flg:        %s", CPCM.Xchngbook.C_slm_flg)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_dsclsd_qty:     %d", CPCM.Xchngbook.L_dsclsd_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_ord_tot_qty:    %d", CPCM.Xchngbook.L_ord_tot_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_ord_lmt_rt:     %d", CPCM.Xchngbook.L_ord_lmt_rt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_stp_lss_tgr:    %d", CPCM.Xchngbook.L_stp_lss_tgr)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_valid_dt:       %s", CPCM.Xchngbook.C_valid_dt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_ord_typ:        %s", CPCM.Xchngbook.C_ord_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_sprd_ord_ind:   %s", CPCM.Xchngbook.C_sprd_ord_ind)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_req_typ:        %s", CPCM.Xchngbook.C_req_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_quote:          %d", CPCM.Xchngbook.L_quote)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_qt_tm:          %s", CPCM.Xchngbook.C_qt_tm)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_rqst_tm:        %s", CPCM.Xchngbook.C_rqst_tm)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_frwrd_tm:       %s", CPCM.Xchngbook.C_frwrd_tm)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_plcd_stts:      %s", CPCM.Xchngbook.C_plcd_stts)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_rms_prcsd_flg:  %s", CPCM.Xchngbook.C_rms_prcsd_flg)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_ors_msg_typ:    %d", CPCM.Xchngbook.L_ors_msg_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_ack_tm:         %s", CPCM.Xchngbook.C_ack_tm)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_xchng_rmrks:    %s", CPCM.Xchngbook.C_xchng_rmrks)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_ex_ordr_typ:    %s", CPCM.Xchngbook.C_ex_ordr_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_xchng_can_qty:  %d", CPCM.Xchngbook.L_xchng_can_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   C_spl_flg:        %s", CPCM.Xchngbook.C_spl_flg)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnSeqToBseOmd]   L_ord_seq:        %d", CPCM.Xchngbook.L_ord_seq)

	return 0
}

func (CPCM *ClnPackClntManager) FnBseRefToOrd() int {

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Function REF_TO_ORD started")
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "c_ordr_rfrnc: %s", CPCM.Orderbook.C_ordr_rfrnc)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Requested Operation: %c", CPCM.Orderbook.C_oprn_typ)

	CPCM.Orderbook.C_ctcl_id = ""
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Initial C_ctcl_id set to empty")

	query := `
SELECT 
    fod_clm_mtch_accnt,
    fod_clnt_ctgry,
    fod_pipe_id,
    fod_xchng_cd,
    CASE WHEN $1 = 'S' THEN 
        (CASE fod_prdct_typ WHEN 'P' THEN 'F' ELSE fod_prdct_typ END) 
    ELSE fod_prdct_typ END AS c_prd_typ,
    fod_undrlyng,
    TO_CHAR(fod_expry_dt, 'dd-Mon-yyyy') AS c_expry_dt,
    fod_exer_typ,
    fod_opt_typ,
    fod_strk_prc,
    fod_ordr_flw,
    fod_lmt_mrkt_sl_flg AS c_slm_flg,
    fod_dsclsd_qty,
    fod_ordr_tot_qty,
    fod_lmt_rt,
    fod_stp_lss_tgr,
    fod_ordr_type AS c_ord_typ,
    TO_CHAR(fod_ordr_valid_dt, 'dd-Mon-yyyy') AS c_valid_dt,
    TO_CHAR(fod_trd_dt, 'dd-Mon-yyyy') AS c_trd_dt,
    fod_ordr_stts,
    fod_exec_qty,
    COALESCE(fod_exec_qty_day, 0) AS l_exctd_qty_day,
    fod_cncl_qty,
    fod_exprd_qty,
    COALESCE(fod_sprd_ordr_ref ,'')AS c_sprd_ord_rfrnc,
    fod_mdfctn_cntr,
    COALESCE(fod_settlor,''),
     COALESCE(fod_ack_nmbr,'') AS c_xchng_ack,
    fod_spl_flag,
    fod_indstk AS c_ctgry_indstk,
    COALESCE(TO_CHAR(fod_ord_ack_tm, 'dd-Mon-yyyy hh24:mi:ss'),'') AS c_ack_tm,
     COALESCE(TO_CHAR(fod_lst_rqst_ack_tm, 'dd-Mon-yyyy hh24:mi:ss'),'') AS c_prev_ack_tm,
    fod_pro_cli_ind,
    COALESCE(fod_ctcl_id, ' ') AS c_ctcl_id,
    fod_channel
FROM 
    fod_fo_ordr_dtls
WHERE 
    fod_ordr_rfrnc = $2
FOR UPDATE OF fod_fo_ordr_dtls NOWAIT;
`
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Executing query to fetch order details")
	fmt.Println("CPCM.Orderbook.C_oprn_typ, CPCM.Orderbook.C_ordr_rfrnc : ", CPCM.Orderbook.C_oprn_typ, CPCM.Orderbook.C_ordr_rfrnc)

	row := CPCM.Db.Raw(query, CPCM.Orderbook.C_oprn_typ, CPCM.Orderbook.C_ordr_rfrnc).Row()

	// --------------------------------------------------------------------------

	// --------------------------------------------------------------------------

	fmt.Println("row : ", row)
	err := row.Scan(
		&CPCM.Orderbook.C_cln_mtch_accnt,
		&CPCM.Orderbook.L_clnt_ctgry,
		&CPCM.Orderbook.C_pipe_id,
		&CPCM.Orderbook.C_xchng_cd,
		&CPCM.Orderbook.C_prd_typ,
		&CPCM.Orderbook.C_undrlyng,
		&CPCM.Orderbook.C_expry_dt,
		&CPCM.Orderbook.C_exrc_typ,
		&CPCM.Orderbook.C_opt_typ,
		&CPCM.Orderbook.L_strike_prc,
		&CPCM.Orderbook.C_ordr_flw,
		&CPCM.Orderbook.C_slm_flg,
		&CPCM.Orderbook.L_dsclsd_qty,
		&CPCM.Orderbook.L_ord_tot_qty,
		&CPCM.Orderbook.L_ord_lmt_rt,
		&CPCM.Orderbook.L_stp_lss_tgr,
		&CPCM.Orderbook.C_ord_typ,
		&CPCM.Orderbook.C_valid_dt,
		&CPCM.Orderbook.C_trd_dt,
		&CPCM.Orderbook.C_ordr_stts,
		&CPCM.Orderbook.L_exctd_qty,
		&CPCM.Orderbook.L_exctd_qty_day,
		&CPCM.Orderbook.L_can_qty,
		&CPCM.Orderbook.L_exprd_qty,
		&CPCM.Orderbook.C_sprd_ord_rfrnc,
		&CPCM.Orderbook.L_mdfctn_cntr,
		&CPCM.Orderbook.C_settlor,
		&CPCM.Orderbook.C_xchng_ack,
		&CPCM.Orderbook.C_spl_flg,
		&CPCM.Orderbook.C_ctgry_indstk,
		&CPCM.Orderbook.C_ack_tm,
		&CPCM.Orderbook.C_prev_ack_tm,
		&CPCM.Orderbook.C_pro_cli_ind,
		&CPCM.Orderbook.C_ctcl_id,
		&CPCM.Orderbook.C_channel,
	)

	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "[FnBseRefToOrd] Error scanning row: %v", err)
		return -1
	}

	// Log fetched data for each field
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Fetched data successfully for order reference: %s", CPCM.Orderbook.C_ordr_rfrnc)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_cln_mtch_accnt: %s", CPCM.Orderbook.C_cln_mtch_accnt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_clnt_ctgry: %s", CPCM.Orderbook.L_clnt_ctgry)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_pipe_id: %s", CPCM.Orderbook.C_pipe_id)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_xchng_cd: %s", CPCM.Orderbook.C_xchng_cd)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_prd_typ: %s", CPCM.Orderbook.C_prd_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_undrlyng: %s", CPCM.Orderbook.C_undrlyng)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_expry_dt: %s", CPCM.Orderbook.C_expry_dt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_exrc_typ: %s", CPCM.Orderbook.C_exrc_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_opt_typ: %s", CPCM.Orderbook.C_opt_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_strike_prc: %f", CPCM.Orderbook.L_strike_prc)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_ordr_flw: %s", CPCM.Orderbook.C_ordr_flw)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_slm_flg: %s", CPCM.Orderbook.C_slm_flg)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_dsclsd_qty: %f", CPCM.Orderbook.L_dsclsd_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_ord_tot_qty: %f", CPCM.Orderbook.L_ord_tot_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_ord_lmt_rt: %f", CPCM.Orderbook.L_ord_lmt_rt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_stp_lss_tgr: %f", CPCM.Orderbook.L_stp_lss_tgr)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_ord_typ: %s", CPCM.Orderbook.C_ord_typ)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_valid_dt: %s", CPCM.Orderbook.C_valid_dt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_trd_dt: %s", CPCM.Orderbook.C_trd_dt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_ordr_stts: %s", CPCM.Orderbook.C_ordr_stts)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_exctd_qty: %f", CPCM.Orderbook.L_exctd_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_exctd_qty_day: %f", CPCM.Orderbook.L_exctd_qty_day)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_can_qty: %f", CPCM.Orderbook.L_can_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_exprd_qty: %f", CPCM.Orderbook.L_exprd_qty)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "L_mdfctn_cntr: %s", CPCM.Orderbook.L_mdfctn_cntr)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_xchng_ack: %s", CPCM.Orderbook.C_xchng_ack)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_spl_flg: %s", CPCM.Orderbook.C_spl_flg)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_ctgry_indstk: %s", CPCM.Orderbook.C_ctgry_indstk)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_pro_cli_ind: %s", CPCM.Orderbook.C_pro_cli_ind)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_ctcl_id: %s", CPCM.Orderbook.C_ctcl_id)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "C_channel: %s", CPCM.Orderbook.C_channel)

	CPCM.Fod_iXchngAck, err = strconv.ParseInt(CPCM.Orderbook.C_xchng_ack, 10, 16)
	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "failed to convert c_xchng_ack to int64: %v", err)
	}
	if CPCM.Fod_iXchngAck < 0 {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "c_xchng_ack was negative; setting to '0'")
		CPCM.Orderbook.C_xchng_ack = "0"
	}

	query = `
	SELECT COALESCE(BTRIM(CLM_CP_CD), ' ') AS clm_cp_cd,
		COALESCE(BTRIM(CLM_CLNT_CD), CLM_MTCH_ACCNT) AS clm_clnt_cd
	FROM   CLM_CLNT_MSTR
	WHERE  CLM_MTCH_ACCNT = $1;
`

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Executing query to fetch client master details for match account: %s", CPCM.Orderbook.C_cln_mtch_accnt)
	row2 := CPCM.Db.Raw(query, CPCM.Orderbook.C_cln_mtch_accnt).Row()

	err = row2.Scan(&CPCM.Fod_c_cp_code, &CPCM.Fod_c_ucc_cd)
	if err != nil {
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "match account is: %s", CPCM.Orderbook.C_cln_mtch_accnt)
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "Error scanning client master row: %v", err)
		return -1
	}

	CPCM.Orderbook.C_cln_mtch_accnt = CPCM.Fod_c_ucc_cd
	CPCM.Orderbook.C_settlor = CPCM.Fod_c_cp_code

	CPCM.Orderbook.C_expry_dt = strings.TrimSpace(CPCM.Orderbook.C_expry_dt)
	CPCM.Orderbook.C_ctcl_id = strings.TrimSpace(CPCM.Orderbook.C_ctcl_id)

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "cp before is: %s", CPCM.Fod_c_cp_code)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "jagan ctcl_id is: %s", CPCM.Orderbook.C_ctcl_id)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "match account after is: %s", CPCM.Orderbook.C_cln_mtch_accnt)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "cp after is: %s", CPCM.Orderbook.C_settlor)

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "Function REF_TO_ORD completed successfully")
	return 0

}

func (CPCM *ClnPackClntManager) FnUpdBseXchngBook() int {

	var iRecExists int
	var cXchngRmrks string

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Entering updateExchangeBook")

	// Log operation type
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Operation Type: %s", CPCM.Xchngbook.C_oprn_typ)

	switch CPCM.Xchngbook.C_oprn_typ {
	case string(util.UPDATION_ON_ORDER_FORWARDING):
		query := `
		UPDATE fxb_fo_xchng_book
		SET fxb_frwd_tm = NOW(),
			fxb_plcd_stts = ?
		WHERE fxb_ordr_rfrnc = ?
		AND fxb_mdfctn_cntr = ?;
	`

		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Executing Query: %s", query)
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Query Parameters: [fxb_plcd_stts: %s, fxb_ordr_rfrnc: %s, fxb_mdfctn_cntr: %d]",
			CPCM.Xchngbook.C_plcd_stts, CPCM.Xchngbook.C_ordr_rfrnc, CPCM.Xchngbook.L_mdfctn_cntr)

		if err := CPCM.Db.Exec(query, CPCM.Xchngbook.C_plcd_stts, CPCM.Xchngbook.C_ordr_rfrnc, CPCM.Xchngbook.L_mdfctn_cntr).Error; err != nil {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, "[updateExchangeBook] Error updating order forwarding: %v", err)
			return -1
		}

		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Successfully updated order forwarding for Order Reference: %s", CPCM.Xchngbook.C_ordr_rfrnc)

	case string(util.UPDATION_ON_EXCHANGE_RESPONSE):
		query := `
		SELECT 1
		FROM fxb_fo_xchng_book
		WHERE FXB_JIFFY = ?
		AND FXB_XCHNG_CD = ?
		AND FXB_PIPE_ID = ?;
	`

		// Log the query and parameters before execution
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Executing Query: %s", query)
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Query Parameters: [FXB_JIFFY: %d, FXB_XCHNG_CD: %s, FXB_PIPE_ID: %s]",
			CPCM.Xchngbook.D_jiffy, CPCM.Xchngbook.C_xchng_cd, CPCM.Xchngbook.C_pipe_id)

		if err := CPCM.Db.Raw(query, CPCM.Xchngbook.D_jiffy, CPCM.Xchngbook.C_xchng_cd, CPCM.Xchngbook.C_pipe_id).Scan(&iRecExists).Error; err != nil {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, "[updateExchangeBook] Error checking record existence: %v", err)
			return -1
		}

		// Log the result of the record existence check
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Record Existence Check Result: %d", iRecExists)

		if iRecExists == 1 {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, "[updateExchangeBook] Record already processed")
			return -1
		}

		cXchngRmrks = strings.TrimSpace(CPCM.Xchngbook.C_xchng_rmrks)
		query = `
		UPDATE fxb_fo_xchng_book
		SET fxb_plcd_stts = ?,
			fxb_rms_prcsd_flg = ?,
			fxb_ors_msg_typ = ?,
			fxb_ack_tm = TO_TIMESTAMP(?, 'DD-Mon-YYYY HH24:MI:SS'),
			fxb_xchng_rmrks = rtrim(fxb_xchng_rmrks) || ?,
			fxb_jiffy = ?
		WHERE fxb_ordr_rfrnc = ?
		AND fxb_mdfctn_cntr = ?;
	`

		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Executing Update Query: %s", query)
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Query Parameters: [fxb_plcd_stts: %s, fxb_rms_prcsd_flg: %s, fxb_ors_msg_typ: %s, fxb_ack_tm: %s, fxb_xchng_rmrks: %s, fxb_jiffy: %d, fxb_ordr_rfrnc: %s, fxb_mdfctn_cntr: %d]",
			CPCM.Xchngbook.C_plcd_stts, CPCM.Xchngbook.C_rms_prcsd_flg, CPCM.Xchngbook.L_ors_msg_typ,
			CPCM.Xchngbook.C_ack_tm, cXchngRmrks, CPCM.Xchngbook.D_jiffy, CPCM.Xchngbook.C_ordr_rfrnc, CPCM.Xchngbook.L_mdfctn_cntr)

		if err := CPCM.Db.Exec(query, CPCM.Xchngbook.C_plcd_stts, CPCM.Xchngbook.C_rms_prcsd_flg, CPCM.Xchngbook.L_ors_msg_typ,
			CPCM.Xchngbook.C_ack_tm, cXchngRmrks, CPCM.Xchngbook.D_jiffy, CPCM.Xchngbook.C_ordr_rfrnc, CPCM.Xchngbook.L_mdfctn_cntr).Error; err != nil {
			CPCM.LoggerManager.LogError(CPCM.ServiceName, "[updateExchangeBook] Error updating exchange response: %v", err)
			return -1
		}

		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Successfully updated exchange response for Order Reference: %s", CPCM.Xchngbook.C_ordr_rfrnc)

	default:
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "[updateExchangeBook] Invalid operation type: %v", CPCM.Xchngbook.C_oprn_typ)
		return -1
	}

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[updateExchangeBook] Exiting updateExchangeBook")
	return 0
}

func (CPCM *ClnPackClntManager) FnUpdBseOrdrBook() int {
	fmt.Println(CPCM.Orderbook.C_ordr_stts, CPCM.Orderbook.C_ordr_rfrnc, "////////////.............")
	err := CPCM.Db.Exec("UPDATE fod_fo_ordr_dtls SET fod_ordr_stts = ? WHERE fod_ordr_rfrnc = ?", CPCM.Orderbook.C_ordr_stts, CPCM.Orderbook.C_ordr_rfrnc).Error
	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "[FnUpdBseXchngBook] failed to update fod_fo_ordr_dtls - SQL: UPDATE fod_fo_ordr_dtls SET fod_ordr_stts=%v WHERE fod_ordr_rfrnc=%v, Error: %v",
			CPCM.Orderbook.C_ordr_stts, CPCM.Orderbook.C_ordr_rfrnc, err)
		return -1
	}
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnUpdBseXchngBook] Successfully updated fod_fo_ordr_dtls - SQL: UPDATE fod_fo_ordr_dtls SET fod_ordr_stts=%v WHERE fod_ordr_rfrnc=%v",
		CPCM.Orderbook.C_ordr_stts, CPCM.Orderbook.C_ordr_rfrnc)
	return 0

}

func (CPCM *ClnPackClntManager) FnGetBseScripCd() int {

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetBseScripCd] In function get_ext_cnt")
	c_expiry_dt = CPCM.VmContract.C_expry_dt
	fmt.Println(")))))))))))))))))))))))))))))))")
	CPCM.VwNseContract = &models.Vw_nse_cntrct{}
	fmt.Println("{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}")
	var param1 int32 = 0
	var param2 int32 = 0
	fmt.Println(CPCM.VmContract.C_xchng_cd,
		CPCM.VmContract.C_prd_typ,
		CPCM.VmContract.C_undrlyng,
		CPCM.VmContract.C_expry_dt,
		CPCM.VmContract.C_exrc_typ,
		CPCM.VmContract.C_opt_typ,
		CPCM.VmContract.L_strike_prc, "+_)^&*()______________++++++++++")
	query := `
	SELECT COALESCE(ftq_token_no, 0) AS l_token_id,
	       COALESCE(ftq_ca_lvl, 0) AS l_ca_lvl
	FROM   ftq_fo_trd_qt
	WHERE  ftq_xchng_cd = $1
	       AND ftq_prdct_typ = CASE 
	                             WHEN $2= 'U' THEN 'F' 
	                             WHEN $2= 'P' THEN 'F' 
	                             WHEN $2= 'I' THEN 'O' 
	                             ELSE $2
	                           END
	       AND ftq_undrlyng = $3
	       AND ftq_expry_dt = TO_DATE($4, 'DD-Mon-YYYY')
	       AND ftq_exer_typ = $5
	       AND ftq_opt_typ = $6
	       AND ftq_strk_prc = $7
	`
	row := CPCM.Db.Raw(query, CPCM.VmContract.C_xchng_cd,
		CPCM.VmContract.C_prd_typ,
		CPCM.VmContract.C_undrlyng,
		CPCM.VmContract.C_expry_dt,
		CPCM.VmContract.C_exrc_typ,
		CPCM.VmContract.C_opt_typ,
		CPCM.VmContract.L_strike_prc).Row()

	err := row.Scan(&param1, &param2)

	fmt.Println("======================")
	CPCM.VwNseContract.L_token_id = param1
	CPCM.VwNseContract.L_ca_lvl = param2

	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, "[FnGetBseScripCd] failed to execute SELECT on ftq_fo_trd_qt - SQL Error: %v", err)
		return -1
	}

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetBseScripCd] Successfully retrieved data - l_token_id: %v, l_ca_lvl: %v",
		CPCM.VwNseContract.L_token_id, CPCM.VwNseContract.L_ca_lvl)

	return 0
}

func (CPCM *ClnPackClntManager) FnBseRjctRcrd() int {
	var c_svm_nm string
	var c_tm_stmp string

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetBseScripCd] Inside function reject record")

	if CPCM.Orderbook.C_prd_typ == string(util.FUTURES) {
		c_svm_nm = "SFO_FUT_ACK"
	} else {
		c_svm_nm = "SFO_OPT_ACK"
	}
	query := `SELECT TO_CHAR(NOW(), 'DD-Mon-YYYY HH24:MI:SS') AS c_tm_stmp`

	row := CPCM.Db.Raw(query).Row()
	err := row.Scan(&c_tm_stmp)
	if err != nil {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [fnRjctRcrd] [Error: getting the system time: %v", err)
		return -1
	}

	CPCM.Xchngbook.C_plcd_stts = string(util.REJECT)
	CPCM.Xchngbook.C_rms_prcsd_flg = string(util.NOT_PROCESSED)
	CPCM.Xchngbook.L_ors_msg_typ = util.ORS_NEW_ORD_RJCT
	CPCM.Xchngbook.C_ack_tm = c_tm_stmp
	CPCM.Xchngbook.C_xchng_rmrks = "Token id not available"
	CPCM.Xchngbook.D_jiffy = 0
	CPCM.Xchngbook.C_oprn_typ = string(util.UPDATION_ON_EXCHANGE_RESPONSE)

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, "[FnGetBseScripCd] Before calling FnUpdBseXchngBook for rejecting record")

	resultTmp := CPCM.FnUpdBseXchngBook()
	if resultTmp != 0 {
		CPCM.LoggerManager.LogError(CPCM.ServiceName, " [FnBseRjctRcrd] [Error: returned from 'FnUpdBseXchngBook' with an Error")
		CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [FnBseRjctRcrd] exiting from 'FnBseRjctRcrd'")

		return -1
	}

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [FnBseRjctRcrd] Time Before calling 'fnUpdXchngbk' : %s ", c_tm_stmp)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [FnBseRjctRcrd]After calling fnUpdXchngbk for rejecting record ")

	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [FnBseRjctRcrd]After calling %s for rejecting record ", c_svm_nm)
	CPCM.LoggerManager.LogInfo(CPCM.ServiceName, " [FnBseRjctRcrd]Order rejection succesfull")

	return 0
}

// SELECT fod_clm_mtch_accnt,fod_clnt_ctgry,fod_pipe_id,fod_xchng_cd,
//    CASE WHEN $1 = 'S' THEN
//         (CASE fod_prdct_typ WHEN 'P' THEN 'F' ELSE fod_prdct_typ END)
//     ELSE fod_prdct_typ END AS c_prd_typ,fod_undrlyng,TO_CHAR(fod_expry_dt, 'dd-Mon-yyyy') AS c_expry_dt,fod_exer_typ,fod_opt_typ,fod_strk_prc,
//     fod_ordr_flw,fod_lmt_mrkt_sl_flg AS c_slm_flg,fod_dsclsd_qty,fod_ordr_tot_qty,fod_lmt_rt,fod_stp_lss_tgr,fod_ordr_type AS c_ord_typ,TO_CHAR(fod_ordr_valid_dt, 'dd-Mon-yyyy') AS c_valid_dt,
//     TO_CHAR(fod_trd_dt, 'dd-Mon-yyyy') AS c_trd_dt,fod_ordr_stts,fod_exec_qty,COALESCE(fod_exec_qty_day, 0) AS l_exctd_qty_day,fod_cncl_qty,fod_exprd_qty,fod_sprd_ordr_ref AS c_sprd_ord_rfrnc,fod_mdfctn_cntr,
//     fod_settlor,fod_ack_nmbr AS c_xchng_ack,fod_spl_flag,fod_indstk AS c_ctgry_indstk,TO_CHAR(fod_ord_ack_tm, 'dd-Mon-yyyy hh24:mi:ss') AS c_ack_tm,
//     TO_CHAR(fod_lst_rqst_ack_tm, 'dd-Mon-yyyy hh24:mi:ss') AS c_prev_ack_tm,fod_pro_cli_ind,COALESCE(fod_ctcl_id, ' ') AS c_ctcl_id,fod_channel
// FROM fod_fo_ordr_dtls
// WHERE
//     fod_ordr_rfrnc = 'ORDR123456789012';

// SELECT fxb_ordr_rfrnc,fxb_lmt_mrkt_sl_flg,fxb_dsclsd_qty, fxb_ordr_tot_qty, fxb_lmt_rt, fxb_stp_lss_tgr,fxb_mdfctn_cntr, TO_CHAR(fxb_ordr_valid_dt, 'dd-mon-yyyy'),
//     CASE WHEN fxb_ordr_type = 'V' THEN 'T' ELSE fxb_ordr_type END,fxb_sprd_ord_ind,fxb_rqst_typ,fxb_quote,TO_CHAR(fxb_qt_tm, 'dd-mon-yyyy hh24:mi:ss'),
//     TO_CHAR(fxb_rqst_tm, 'dd-mon-yyyy hh24:mi:ss'),TO_CHAR(fxb_frwd_tm, 'dd-mon-yyyy hh24:mi:ss'),fxb_plcd_stts,
//     fxb_rms_prcsd_flg,fxb_ors_msg_typ,TO_CHAR(fxb_ack_tm, 'dd-mon-yyyy hh24:mi:ss'),fxb_xchng_rmrks,fxb_ex_ordr_typ,
//     fxb_xchng_cncld_qty,fxb_spl_flag,fxb_ordr_sqnc FROM  FXB_FO_XCHNG_BOOK
// WHERE fxb_xchng_cd ='EX1' AND fxb_pipe_id = '01' AND fxb_mod_trd_dt = TO_TIMESTAMP('2024-10-17T09:30:00Z', 'yyyy-mm-dd"T"hh24:mi:ss"Z"') AND fxb_ordr_sqnc = (
//         SELECT MIN(fxb_b.fxb_ordr_sqnc) FROM FXB_FO_XCHNG_BOOK fxb_b WHERE  fxb_b.fxb_xchng_cd ='EX1' AND fxb_b.fxb_mod_trd_dt = TO_TIMESTAMP('2024-10-17T09:30:00Z', 'yyyy-mm-dd"T"hh24:mi:ss"Z"') AND fxb_b.fxb_pipe_id = '01'
//             AND fxb_b.fxb_plcd_stts = 'R' AND COALESCE(fxb_b.fxb_rms_prcsd_flg, '*') != 'P' )

// SELECT COALESCE(ftq_token_no, 0) AS l_token_id,COALESCE(ftq_ca_lvl, 0) AS l_ca_lvl
// 	FROM   ftq_fo_trd_qt WHERE  ftq_xchng_cd = 'BSE' AND ftq_prdct_typ = 'F'
// 	       AND ftq_undrlyng = 'BSESEN' AND ftq_expry_dt = TO_DATE('28-Jun-2024', 'DD-Mon-YYYY') AND ftq_exer_typ = 'E'  AND ftq_opt_typ = '*'  AND ftq_strk_prc = 0
